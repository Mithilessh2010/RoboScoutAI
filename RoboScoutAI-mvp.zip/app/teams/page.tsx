import { redirect } from "next/navigation";
import { currentSeason } from "@/lib/mock-data";

export default function TeamsPage() {
  redirect(`/seasons/${currentSeason.id}/teams`);
}
