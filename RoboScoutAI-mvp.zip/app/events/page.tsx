import { redirect } from "next/navigation";
import { currentSeason } from "@/lib/mock-data";

export default function EventsPage() {
  redirect(`/seasons/${currentSeason.id}/events`);
}
