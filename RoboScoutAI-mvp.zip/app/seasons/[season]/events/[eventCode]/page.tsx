import Link from "next/link";
import { notFound } from "next/navigation";
import { MatchTable } from "@/components/events/match-table";
import { PageShell } from "@/components/shared/page-shell";
import { OprTable } from "@/components/stats/opr-table";
import { LinkButton } from "@/components/ui/button";
import { Card, MetricCard } from "@/components/ui/card";
import { Table, Td, Th } from "@/components/ui/table";
import { awards, getEvent, getEventMatches, getTeam, rankings, streamLinks } from "@/lib/mock-data";
import { formatDate } from "@/lib/utils";

export default async function EventDetailPage({ params }: { params: Promise<{ season: string; eventCode: string }> }) {
  const { season, eventCode } = await params;
  const event = getEvent(eventCode, season);
  if (!event) notFound();
  const eventMatches = getEventMatches(event.code);
  const eventRankings = rankings.filter((ranking) => ranking.eventCode === event.code).sort((a, b) => a.rank - b.rank);
  const eventAwards = awards.filter((award) => award.eventCode === event.code);
  const streams = streamLinks.filter((stream) => stream.eventCode === event.code);
  return (
    <PageShell title={event.name} eyebrow={`${event.code} · ${event.city}, ${event.state}`} actions={<LinkButton href={`/seasons/${season}/events/${event.code}/watch`}>Watch Room</LinkButton>}>
      <div className="grid gap-4 md:grid-cols-4">
        <MetricCard label="Teams" value={event.teamNumbers.length} />
        <MetricCard label="Matches" value={eventMatches.length} />
        <MetricCard label="Streams" value={streams.length} />
        <MetricCard label="Dates" value={formatDate(event.startDate)} detail={formatDate(event.endDate)} />
      </div>
      <div className="mt-8 grid gap-6 xl:grid-cols-[1fr_420px]">
        <section className="space-y-6">
          <div><h2 className="mb-3 text-xl font-semibold text-[#F1E9E9]">Match Schedule and Results</h2><MatchTable matches={eventMatches} /></div>
          <div><h2 className="mb-3 text-xl font-semibold text-[#F1E9E9]">OPR / Stat Table</h2><OprTable matches={eventMatches} /></div>
        </section>
        <aside className="space-y-6">
          <Card>
            <h2 className="text-xl font-semibold text-[#F1E9E9]">Teams Attending</h2>
            <div className="mt-3 grid grid-cols-2 gap-2">{event.teamNumbers.map((number) => <Link key={number} className="rounded-md bg-[#F1E9E9]/5 p-2 text-sm text-[#E491C9]" href={`/seasons/${season}/teams/${number}`}>{number} {getTeam(number)?.name}</Link>)}</div>
          </Card>
          <Card>
            <h2 className="text-xl font-semibold text-[#F1E9E9]">Rankings</h2>
            <Table className="mt-3"><thead><tr><Th>#</Th><Th>Team</Th><Th>Record</Th><Th>RP</Th></tr></thead><tbody>{eventRankings.slice(0, 10).map((row) => <tr key={row.teamNumber}><Td>{row.rank}</Td><Td>{row.teamNumber}</Td><Td>{row.wins}-{row.losses}-{row.ties}</Td><Td>{row.rp}</Td></tr>)}</tbody></Table>
          </Card>
          <Card>
            <h2 className="text-xl font-semibold text-[#F1E9E9]">Awards</h2>
            <div className="mt-3 space-y-2">{eventAwards.length ? eventAwards.map((award) => <div key={`${award.name}-${award.recipient}`} className="rounded-md bg-[#F1E9E9]/5 p-3 text-sm text-[#F1E9E9]/72">{award.name}: {award.recipient}</div>) : <p className="text-sm text-[#F1E9E9]/62">No awards in mock data.</p>}</div>
          </Card>
        </aside>
      </div>
    </PageShell>
  );
}
