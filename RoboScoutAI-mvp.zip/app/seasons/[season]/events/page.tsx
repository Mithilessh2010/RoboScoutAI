import { EventTable } from "@/components/events/event-table";
import { PageShell } from "@/components/shared/page-shell";
import { SeasonSwitcher } from "@/components/shared/season-switcher";
import { getSeasonEvents } from "@/lib/mock-data";

export default async function SeasonEventsPage({ params }: { params: Promise<{ season: string }> }) {
  const { season } = await params;
  return (
    <PageShell title="Events" eyebrow={season} actions={<SeasonSwitcher season={season} />}>
      <EventTable events={getSeasonEvents(season)} />
    </PageShell>
  );
}
