import { PageShell } from "@/components/shared/page-shell";
import { SeasonSwitcher } from "@/components/shared/season-switcher";
import { TeamTable } from "@/components/teams/team-table";
import { getSeasonTeams } from "@/lib/mock-data";

export default async function SeasonTeamsPage({ params }: { params: Promise<{ season: string }> }) {
  const { season } = await params;
  return (
    <PageShell title="Teams" eyebrow={season} actions={<SeasonSwitcher season={season} />}>
      <TeamTable teams={getSeasonTeams(season)} season={season} />
    </PageShell>
  );
}
