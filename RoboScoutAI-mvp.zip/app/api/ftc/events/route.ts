import { NextResponse } from "next/server";
import { getSeasonEvents } from "@/lib/mock-data";
import { requestFtcApi } from "@/lib/ftc-api/client";

export async function GET(request: Request) {
  const params = new URL(request.url).searchParams;
  const season = params.get("season") ?? "2025";
  const seasonId = season.includes("-") ? season : `${season}-${Number(season) + 1}`;
  const data = await requestFtcApi("events", { season: Number(String(season).slice(0, 4)) }, { events: getSeasonEvents(seasonId) });
  return NextResponse.json(data);
}
