import { NextResponse } from "next/server";
import { getSeasonTeams } from "@/lib/mock-data";
import { requestFtcApi } from "@/lib/ftc-api/client";

export async function GET(request: Request) {
  const params = new URL(request.url).searchParams;
  const season = params.get("season") ?? "2025";
  const data = await requestFtcApi("teams", { season: Number(String(season).slice(0, 4)) }, { teams: getSeasonTeams(season.includes("-") ? season : `${season}-${Number(season) + 1}`) });
  return NextResponse.json(data);
}
