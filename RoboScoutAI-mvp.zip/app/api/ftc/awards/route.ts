import { NextResponse } from "next/server";
import { awards } from "@/lib/mock-data";
import { requestFtcApi } from "@/lib/ftc-api/client";

export async function GET(request: Request) {
  const params = new URL(request.url).searchParams;
  const season = params.get("season") ?? "2025";
  const eventCode = params.get("eventCode");
  if (!eventCode) return NextResponse.json({ error: "eventCode is required" }, { status: 400 });
  const data = await requestFtcApi("awards", { season: Number(String(season).slice(0, 4)), eventCode }, { awards: awards.filter((award) => award.eventCode === eventCode) });
  return NextResponse.json(data);
}
