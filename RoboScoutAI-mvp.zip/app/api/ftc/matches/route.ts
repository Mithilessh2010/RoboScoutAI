import { NextResponse } from "next/server";
import { matches } from "@/lib/mock-data";
import { requestFtcApi } from "@/lib/ftc-api/client";

export async function GET(request: Request) {
  const params = new URL(request.url).searchParams;
  const season = params.get("season") ?? "2025";
  const eventCode = params.get("eventCode");
  if (!eventCode) return NextResponse.json({ error: "eventCode is required" }, { status: 400 });
  const data = await requestFtcApi("matches", { season: Number(String(season).slice(0, 4)), eventCode }, { matches: matches.filter((match) => match.eventCode === eventCode) });
  return NextResponse.json(data);
}
