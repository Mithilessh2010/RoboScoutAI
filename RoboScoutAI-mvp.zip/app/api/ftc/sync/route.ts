import { NextResponse } from "next/server";
import { getFtcApiStatus } from "@/lib/ftc-api/client";
import { syncFtcScope } from "@/lib/ftc-api/sync";

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  const scope = body.scope ?? "seasons";
  const status = getFtcApiStatus();
  if (!status.configured) {
    return NextResponse.json(
      {
        status: "skipped",
        warning: "FTC API credentials are not configured. Add FTC_API_USERNAME and FTC_API_TOKEN server-side to enable live sync.",
      },
      { status: 200 },
    );
  }

  const result = await syncFtcScope(scope, { season: body.season, eventCode: body.eventCode });
  return NextResponse.json(result);
}
