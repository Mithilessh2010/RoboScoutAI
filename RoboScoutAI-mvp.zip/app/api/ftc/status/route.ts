import { NextResponse } from "next/server";
import { getFtcApiStatus, getLastFtcSyncLog } from "@/lib/ftc-api/client";

export async function GET() {
  const status = getFtcApiStatus();
  const lastSync = await getLastFtcSyncLog();
  return NextResponse.json({
    configured: status.configured,
    baseUrl: status.baseUrl,
    usernameConfigured: status.usernameConfigured,
    tokenConfigured: status.tokenConfigured,
    lastSync,
  });
}
