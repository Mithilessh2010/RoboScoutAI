import { NextResponse } from "next/server";
import { seasons } from "@/lib/mock-data";
import { requestFtcApi } from "@/lib/ftc-api/client";

export async function GET() {
  const data = await requestFtcApi("seasons", {}, { seasons: seasons.map((season) => season.year), mockSeasons: seasons });
  return NextResponse.json(data);
}
