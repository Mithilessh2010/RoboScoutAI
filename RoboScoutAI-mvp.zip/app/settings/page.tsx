import { PageShell } from "@/components/shared/page-shell";
import { FtcApiAdmin } from "@/components/settings/ftc-api-admin";
import { Card } from "@/components/ui/card";

export default function SettingsPage() {
  return (
    <PageShell title="Settings" eyebrow="Configuration">
      <div className="grid gap-4 md:grid-cols-2">
        <Card><h2 className="text-xl font-semibold text-[#F1E9E9]">Theme</h2><p className="mt-2 text-sm text-[#F1E9E9]/62">Dark robotics theme is enabled for the MVP. Theme controls are scaffolded.</p></Card>
        <Card><h2 className="text-xl font-semibold text-[#F1E9E9]">Data Sources</h2><p className="mt-2 text-sm text-[#F1E9E9]/62">Mock data is active. Prisma schema is included so the app can move to SQLite or PostgreSQL.</p></Card>
        <Card><h2 className="text-xl font-semibold text-[#F1E9E9]">OpenRouter</h2><p className="mt-2 text-sm text-[#F1E9E9]/62">Create `.env.local` with `OPENROUTER_API_KEY=` to enable `/api/ai/chat`.</p></Card>
        <Card><h2 className="text-xl font-semibold text-[#F1E9E9]">Season Configuration</h2><p className="mt-2 text-sm text-[#F1E9E9]/62">DECODE config lives in `lib/game-config/2025-2026-decode.ts`; past seasons fall back to generic configurable scouting categories.</p></Card>
      </div>
      <div className="mt-6">
        <FtcApiAdmin />
      </div>
    </PageShell>
  );
}
